package com.example.flutter_pbm2

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
